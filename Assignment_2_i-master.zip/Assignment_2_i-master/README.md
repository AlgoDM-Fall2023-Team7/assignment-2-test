# Assignment 2

Add your own credentials in secrets.toml .

`Note: Keep the name of your virtual environment as 'snow' to avoid merge conflict later.`

After activating virtual env, run command.

```pip install -r requirements.txt```

Dont try and change the .gitignore. Do not upload venv folder. Not a good practice !.

For SQL queries of your part, create new folders inside the `queries` folder and add your queries inside over there. Eg `queries/anaomalies/query1.sql`